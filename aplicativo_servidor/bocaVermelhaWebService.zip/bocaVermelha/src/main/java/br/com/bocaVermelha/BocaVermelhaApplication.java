package br.com.bocaVermelha;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("br.com.bocaVermelha.*")
public class BocaVermelhaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BocaVermelhaApplication.class, args);
	}

}
