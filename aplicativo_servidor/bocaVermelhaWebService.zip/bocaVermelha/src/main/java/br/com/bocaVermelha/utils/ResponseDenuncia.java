package br.com.bocaVermelha.utils;

/**
 * Classe utilitária para montagem de um objeto de retorno no Controller Denúncia.
 */
public class ResponseDenuncia {
	private String code;
	private String message;
	
	public ResponseDenuncia(String code, String message) {
		super();
		this.code = code;
		this.message = message;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
