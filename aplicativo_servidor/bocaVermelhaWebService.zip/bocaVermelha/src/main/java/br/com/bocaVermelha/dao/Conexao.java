package br.com.bocaVermelha.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Classe que irá realizar as conexões com o banco de dados.
 * É utilizada pela camada de DAO.
 *
 */
public class Conexao {
	
	public static Connection abrirConexao() throws SQLException, ClassNotFoundException {
		String url      = "jdbc:mysql://localhost:3306/db_bocavermelha";
		String user     = "usuario_banco";		 
        String password = "senha_banco";
        
        Class.forName("com.mysql.cj.jdbc.Driver");
        
        Connection conexao = null;
        conexao = DriverManager.getConnection(url, user, password);
         
        return conexao;
	}
	
}
