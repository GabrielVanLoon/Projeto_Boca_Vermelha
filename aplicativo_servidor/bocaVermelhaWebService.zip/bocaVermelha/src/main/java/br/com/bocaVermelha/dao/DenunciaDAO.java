package br.com.bocaVermelha.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import br.com.bocaVermelha.entities.Denuncia;

/**
 * Data Access Object Denúncia
 * 
 * Responsável pelas comunicações Banco <-> Servidor que envolvem a entidade
 * do tipo Denúncia.
 *
 */
public class DenunciaDAO {
	
	private Connection        con;
	private PreparedStatement stmt;
	
	public DenunciaDAO() { }
	
	/**
	 * Insere uma nova denúncia no banco de dados.
	 * @param  denuncia
	 * @return den_id da denúncia inserida.
	 * @throws Exception
	 */
	public int inserir(Denuncia denuncia) throws Exception {
		int    id = 0;
		String query = "INSERT INTO DENUNCIA" + 
				"(den_nome_vitima,den_endereco_vitima,fae_id_vitima," + 
				"den_nome_suspeito,den_endereco_suspeito,fae_id_suspeito,den_outros_suspeitos,con_id," + 
				"den_local_ocorrencia,den_desc_ocorrencia,den_uf_ocorrencia,cat_id," + 
				"sta_id,den_cd_acompanhamento,den_dt_criacao,den_dt_modificacao,den_mensagem)" +
				"VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,NOW(),NOW(),?)";
		
		try {
			con = Conexao.abrirConexao();
		
			stmt = con.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
			
			stmt.setString(1,  denuncia.getNomeVitima());
			stmt.setString(2,  denuncia.getEnderecoVitima());
			stmt.setInt(   3,  denuncia.getIdFaixaEtariaVitima());
			stmt.setString(4,  denuncia.getNomeSuspeito());
			stmt.setString(5,  denuncia.getEnderecoSuspeito());
			stmt.setInt(   6,  denuncia.getIdFaixaEtariaSuspeito());
			stmt.setString(7,  denuncia.getNomesOutrosSuspeitos());
			stmt.setInt(   8,  denuncia.getIdConexaoVitimaSuspeito());
			stmt.setString(9,  denuncia.getLocalOcorrencia());
			stmt.setString(10, denuncia.getDescricaoOcorrencia());
			stmt.setString(11, denuncia.getUfOcorrencia());
			stmt.setInt(   12, denuncia.getIdCategoria());
			stmt.setInt(   13, denuncia.getIdStatus());
			stmt.setString(14, denuncia.getCodigoAcompanhamento());
			stmt.setString(15, denuncia.getMensagem());
			
			// Executa a query
			stmt.execute();
			
			ResultSet rs = stmt.getGeneratedKeys();
			
			if(rs.next()) {
				id = rs.getInt(1);
			}
		
		} catch(Exception e) {
			System.out.println(e.getMessage());
			throw e;
		} finally {
			if(stmt != null) {
				stmt.close();
			}
			if(con != null) {
				con.setAutoCommit(true);
			}
		}
		
		return id;
	}
	
	/**
	 * Atualiza o código de acompanhamento da denúncia para o valor definido.
	 * @param  denuncia
	 * @throws Exception
	 */
	public void atualizarCodigoAcompanhamento(Denuncia denuncia) throws Exception {
		String query = "UPDATE DENUNCIA SET den_cd_acompanhamento=? WHERE den_id=?";
		
		try {
			con = Conexao.abrirConexao();
			stmt = con.prepareStatement(query);
			stmt.setString(1, denuncia.getCodigoAcompanhamento());
			stmt.setInt(2, denuncia.getId());
			
			// Executa a query
			stmt.executeUpdate();
			
		} catch(Exception e) {
			System.out.println(e.getMessage());
			throw new Exception(e);
		} finally {
			if(stmt != null) {
				stmt.close();
			}
		}
	}
	
	/**
	 * Busca e retorna uma denúncia por meio de seu código de acompanhamento.
	 * @param  denuncia
	 * @throws Exception
	 */
	public void buscarPeloAcompanhamento(Denuncia denuncia) throws Exception{
		String query = "SELECT * FROM DENUNCIA WHERE den_cd_acompanhamento=? LIMIT 1";
		
		try {
			con = Conexao.abrirConexao();
			stmt = con.prepareStatement(query);
			stmt.setString(1, denuncia.getCodigoAcompanhamento());
			
			ResultSet rs = stmt.executeQuery();
			
			if(rs.next()) {
				denuncia.setId(rs.getInt("den_id"));
				denuncia.setNomeVitima(rs.getString("den_nome_vitima"));
				denuncia.setEnderecoVitima(rs.getString("den_endereco_vitima"));
				denuncia.setIdFaixaEtariaVitima(rs.getInt("fae_id_vitima"));
				
				denuncia.setNomeSuspeito(rs.getString("den_nome_suspeito"));
				denuncia.setEnderecoSuspeito(rs.getString("den_endereco_suspeito"));
				denuncia.setIdFaixaEtariaSuspeito(rs.getInt("fae_id_suspeito"));
				
				denuncia.setNomesOutrosSuspeitos(rs.getString("den_outros_suspeitos"));
				denuncia.setIdConexaoVitimaSuspeito(rs.getInt("con_id"));
				
				denuncia.setLocalOcorrencia(rs.getString("den_local_ocorrencia"));
				denuncia.setDescricaoOcorrencia(rs.getString("den_desc_ocorrencia"));
				denuncia.setUfOcorrencia(rs.getString("den_uf_ocorrencia"));
				denuncia.setIdCategoria(rs.getInt("cat_id"));
				
				denuncia.setIdStatus(rs.getInt("sta_id"));
				denuncia.setDataCriacao(rs.getDate("den_dt_criacao"));
				denuncia.setDataModificacao(rs.getDate("den_dt_modificacao"));
				denuncia.setMensagem(rs.getString("den_mensagem"));
			
			} else {
				throw new Exception("Nenhum registro encontrado");
			}
			
		} catch(Exception e) {
			System.out.println(e.getMessage());
			throw new Exception(e);
		} finally {
			if(stmt != null) { stmt.close(); }
			if(con != null) { con.close(); }	
		}
	}
	
	/**
	 * Conta e retorna a quantidade de denúncias que há para cada tipo de categoria.
	 * @throws Exception
	 */
	public Map<String, Object> buscarEstatisticasCategorias() throws Exception{
		Map<String, Object> geral = new HashMap<String, Object>();
		String query = "SELECT\n" + 
						"    d.cat_id as 'id', " + 
						"    c.cat_descricao as 'descricao', " + 
						"    COUNT(1) as 'count' " + 
						"FROM DENUNCIA AS d " + 
						"INNER JOIN CATEGORIA AS c ON c.cat_id = d.cat_id " + 
						"GROUP BY d.cat_id;";
		int contador = 0;
		
		try {
			con = Conexao.abrirConexao();
			stmt = con.prepareStatement(query);
			
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				Map<String, Object> dado = new HashMap<String, Object>();
				dado.put("id", rs.getInt("id"));
				dado.put("descricao", rs.getString("descricao"));
				dado.put("count", rs.getInt("count"));
				geral.put(Integer.toString(++contador), dado);
			}
			geral.put("num_rows", contador);
			
			
		} catch(Exception e) {
			System.out.println(e.getMessage());
			throw new Exception(e);
		} finally {
			if(stmt != null){ stmt.close(); }
			if(con != null) { con.close();  }	
		}
		
		return geral;
	}
	
	/**
	 * Conta e retorna a quantidade de vitimas que há em cada faixa etária.
	 * @throws Exception
	 */
	public Map<String, Object> buscarEstatisticasIdadeVitima() throws Exception{
		Map<String, Object> geral = new HashMap<String, Object>();
		String query = "SELECT " + 
						"    d.fae_id_vitima as 'id', " + 
						"    f.fae_descricao as 'descricao', " + 
						"    COUNT(1) as 'count' " + 
						"FROM DENUNCIA AS d\n" + 
						"INNER JOIN FAIXA_ETARIA AS f ON f.id = d.fae_id_vitima " + 
						"GROUP BY d.fae_id_vitima;";
		int contador = 0;
		
		try {
			con = Conexao.abrirConexao();
			stmt = con.prepareStatement(query);
			
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				Map<String, Object> dado = new HashMap<String, Object>();
				dado.put("id", rs.getInt("id"));
				dado.put("descricao", rs.getString("descricao"));
				dado.put("count", rs.getInt("count"));
				geral.put(Integer.toString(++contador), dado);
			}
			geral.put("num_rows", contador);
			
			
		} catch(Exception e) {
			System.out.println(e.getMessage());
			throw new Exception(e);
		} finally {
			if(stmt != null){ stmt.close(); }
			if(con != null) { con.close();  }	
		}
		
		return geral;
	}
	
	/**
	 * Conta e retorna a quantidade de denúncia separadas por tipo de conexão entre vitima-suspeito
	 * @throws Exception
	 */
	public Map<String, Object> buscarEstatisticasConexao() throws Exception{
		Map<String, Object> geral = new HashMap<String, Object>();
		String query = "SELECT " + 
						"    d.con_id as 'id', " + 
						"    c.con_descricao as 'descricao', " + 
						"    COUNT(1) as 'count' " + 
						"FROM DENUNCIA AS d " + 
						"INNER JOIN CONEXAO AS c ON c.con_id = d.con_id " + 
						"GROUP BY d.con_id;";
		int contador = 0;
		
		try {
			con = Conexao.abrirConexao();
			stmt = con.prepareStatement(query);
			
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()) {
				Map<String, Object> dado = new HashMap<String, Object>();
				dado.put("id", rs.getInt("id"));
				dado.put("descricao", rs.getString("descricao"));
				dado.put("count", rs.getInt("count"));
				geral.put(Integer.toString(++contador), dado);
			}
			geral.put("num_rows", contador);
			
			
		} catch(Exception e) {
			System.out.println(e.getMessage());
			throw new Exception(e);
		} finally {
			if(stmt != null){ stmt.close(); }
			if(con != null) { con.close();  }	
		}
		
		return geral;
	}
}
