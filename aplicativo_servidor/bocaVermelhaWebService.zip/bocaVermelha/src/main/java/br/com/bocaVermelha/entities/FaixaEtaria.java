package br.com.bocaVermelha.entities;

/**
 * Entity FaixaEtaria
 * 
 * Implementa as possíveis faixa etarias que o sistema irá lidar.
 */
public class FaixaEtaria {
	
	public static final int ATE_14      = 1;
	public static final int ENTRE_15_24 = 2;
	public static final int ENTRE_25_34 = 3;
	public static final int ENTRE_35_44 = 4;
	public static final int ENTRE_45_54 = 5;
	public static final int ACIMA_55    = 6;
	
	public static boolean isValid(int id) {
		return (1 <= id && id <= 6);
	}
}
