package br.com.bocaVermelha.controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import br.com.bocaVermelha.entities.Denuncia;
import br.com.bocaVermelha.models.DenunciaModel;
import br.com.bocaVermelha.utils.ResponseDenuncia;

/**
 * Controller Denuncia
 * 
 * Realiza o mapeamento das URL's da API com as suas respectivas regras de negócio
 * no Model.
 */
@RequestMapping("/denuncia")
@RestController
public class DenunciaController {
	
	private DenunciaModel denunciaModel = new DenunciaModel();
	
	@PostMapping(value="/cadastrar", produces = "application/json")
	public ResponseEntity<Object> cadastrar(@RequestBody Denuncia denuncia) {
		ResponseDenuncia response;
		
		try {
			denunciaModel.cadastrar(denuncia);
		} catch (Exception e) {
			response = new ResponseDenuncia("", e.getMessage());
			return new ResponseEntity<Object>(response, HttpStatus.BAD_REQUEST);
		}
		
		response = new ResponseDenuncia(denuncia.getCodigoAcompanhamento(), "Cadastro realizado com sucesso!");
		return new ResponseEntity<Object>(response, HttpStatus.OK);
	}
	
	@PostMapping(value="/acompanhamento", produces = "application/json")
	public ResponseEntity<Object> acompanhar(@RequestBody Denuncia denuncia) {
		ResponseDenuncia errorResponse;
		
		try {
			denunciaModel.acompanhar(denuncia);
		} catch(Exception e) {
			errorResponse = new ResponseDenuncia(null, e.getMessage());
			return new ResponseEntity<Object>(errorResponse, HttpStatus.BAD_REQUEST);
		}
		
		return new ResponseEntity<Object>(denuncia, HttpStatus.OK);
	}
	
	@PostMapping(value="/estatisticas", produces = "application/json")
	public ResponseEntity<Object> estatisticas() {
		ResponseDenuncia errorResponse;
		Map<String, Object> response = null;
		
		try {
			response = denunciaModel.buscarEstatisticas();
		} catch(Exception e) {
			errorResponse = new ResponseDenuncia(null, e.getMessage());
			return new ResponseEntity<Object>(errorResponse, HttpStatus.BAD_REQUEST);
		}
		
		return new ResponseEntity<Object>(response, HttpStatus.OK);
	}
	
}
