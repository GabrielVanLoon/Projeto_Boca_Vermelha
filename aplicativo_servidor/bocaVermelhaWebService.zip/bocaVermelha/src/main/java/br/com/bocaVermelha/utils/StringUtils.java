package br.com.bocaVermelha.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Classe utilitária para realizar operações que utilizam Strings.
 */
public class StringUtils {
	
	/**
	 * Verifica se uma string esta vazia.
	 */
	public static boolean isBlank(String s) {
		return s == null || s.trim().equals(""); 
	}
	
	/**
	 * Gera um código de acompanhamento utilizando a data atual e também um id
	 * utilizado para diferenciar protocolos gerados no mesmo instante.
	 */
	public static String gerarProtocolo(int id) {
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		Calendar   calendar   = Calendar.getInstance();
		return dateFormat.format(calendar.getTime()) + String.format("%02d", id%100);  
	}
	
}
