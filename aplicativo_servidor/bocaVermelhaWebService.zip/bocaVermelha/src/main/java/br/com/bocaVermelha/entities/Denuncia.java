package br.com.bocaVermelha.entities;

import java.util.Date;

/**
 * Entity Denuncia
 * 
 * Implementa os atributos padrões definidos em uma entidade do tipo denúncia.
 */
public class Denuncia {
	
	// Dados da vítima
	private String  nomeVitima;
	private String  enderecoVitima;
	private Integer idFaixaEtariaVitima;
	
	// Dados do(s) suspeito(s)
	private String  nomeSuspeito;
	private String  enderecoSuspeito;
	private Integer idFaixaEtariaSuspeito;
	private String  nomesOutrosSuspeitos;
	
	// Tipo de conexão entre vitima-suspeito
	private Integer idConexaoVitimaSuspeito;
	
	// Dados da Ocorrência
	private String  localOcorrencia;
	private String  descricaoOcorrencia;
	private String  ufOcorrencia;
	private Integer idCategoria;
	
	// Metadados e informações da ocorrência
	private Integer id;
	private String  codigoAcompanhamento;
	private Integer idStatus;
	private Date    dataCriacao;
	private Date    dataModificacao;
	private String  mensagem;
	
	// Getters and Setters
	public String getNomeVitima() {
		return nomeVitima;
	}
	public void setNomeVitima(String nomeVitima) {
		this.nomeVitima = nomeVitima;
	}
	
	public String getEnderecoVitima() {
		return enderecoVitima;
	}
	public void setEnderecoVitima(String enderecoVitima) {
		this.enderecoVitima = enderecoVitima;
	}
	
	public Integer getIdFaixaEtariaVitima() {
		return idFaixaEtariaVitima;
	}
	public void setIdFaixaEtariaVitima(Integer idFaixaEtariaVitima) {
		this.idFaixaEtariaVitima = idFaixaEtariaVitima;
	}
	
	public String getNomeSuspeito() {
		return nomeSuspeito;
	}
	public void setNomeSuspeito(String nomeSuspeito) {
		this.nomeSuspeito = nomeSuspeito;
	}
	
	public String getEnderecoSuspeito() {
		return enderecoSuspeito;
	}
	public void setEnderecoSuspeito(String enderecoSuspeito) {
		this.enderecoSuspeito = enderecoSuspeito;
	}
	
	public Integer getIdFaixaEtariaSuspeito() {
		return idFaixaEtariaSuspeito;
	}
	public void setIdFaixaEtariaSuspeito(Integer idFaixaEtariaSuspeito) {
		this.idFaixaEtariaSuspeito = idFaixaEtariaSuspeito;
	}
	
	public String getNomesOutrosSuspeitos() {
		return nomesOutrosSuspeitos;
	}
	public void setNomesOutrosSuspeitos(String nomesOutrosSuspeitos) {
		this.nomesOutrosSuspeitos = nomesOutrosSuspeitos;
	}
	
	public Integer getIdConexaoVitimaSuspeito() {
		return idConexaoVitimaSuspeito;
	}
	public void setIdConexaoVitimaSuspeito(Integer idConexaoVitimaSuspeito) {
		this.idConexaoVitimaSuspeito = idConexaoVitimaSuspeito;
	}
	
	public String getLocalOcorrencia() {
		return localOcorrencia;
	}
	public void setLocalOcorrencia(String localOcorrencia) {
		this.localOcorrencia = localOcorrencia;
	}
	
	public String getDescricaoOcorrencia() {
		return descricaoOcorrencia;
	}
	public void setDescricaoOcorrencia(String descricaoOcorrencia) {
		this.descricaoOcorrencia = descricaoOcorrencia;
	}
	
	public Integer getIdCategoria() {
		return idCategoria;
	}
	public void setIdCategoria(Integer idCategoria) {
		this.idCategoria = idCategoria;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getCodigoAcompanhamento() {
		return codigoAcompanhamento;
	}
	public void setCodigoAcompanhamento(String codigoAcompanhamento) {
		this.codigoAcompanhamento = codigoAcompanhamento;
	}
	
	public Date getDataCriacao() {
		return dataCriacao;
	}
	public void setDataCriacao(Date dataCriação) {
		this.dataCriacao = dataCriação;
	}
	
	public Date getDataModificacao() {
		return dataModificacao;
	}
	public void setDataModificacao(Date dataModificação) {
		this.dataModificacao = dataModificação;
	}
	
	public String getMensagem() {
		return mensagem;
	}
	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}
	public String getUfOcorrencia() {
		return ufOcorrencia;
	}
	public void setUfOcorrencia(String ufOcorrencia) {
		this.ufOcorrencia = ufOcorrencia;
	}
	public Integer getIdStatus() {
		return idStatus;
	}
	public void setIdStatus(Integer idStatus) {
		this.idStatus = idStatus;
	}

}
