package br.com.bocaVermelha.entities;

/**
 * Entity Conexao
 * 
 * Implementa os tipos de conexao que podem haver entre uma vitima 
 * e um suspeito de uma Denúncia.
 */
public class Conexao {
	
	public static final int PARCEIRO     = 1;
	public static final int EX_PARCEIRO  = 2;
	public static final int FAMILIAR     = 3;
	public static final int PROFISSIONAL = 4;
	public static final int AMIGO        = 5;
	public static final int DESCONHECIDO = 6;
	
	public static boolean isValid(int id) {
		return (1 <= id && id <= 6);
	}
}
