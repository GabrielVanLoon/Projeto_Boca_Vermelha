package br.com.bocaVermelha.entities;

/**
 * Entity Status
 * 
 * Implementa os tipos possiveis de categoria em que uma Denúncia pode se enquadrar.
 */
public class Categoria {
	
	public static final int VIOLENCIA_DOMESTICA  = 1;
	public static final int AGRESSAO_FISICA      = 2;
	public static final int AGRESSAO_PSICO_MORAL = 3;
	public static final int VIOLENCIA_SEXUAL     = 4;
	public static final int FEMINICIDIO          = 5;
	public static final int CARCERE_PRIVADO      = 6;
	public static final int TRAFICO_MULHERES     = 7;
	public static final int OUTRA                = 8;
	
	
	public static boolean isValid(int id) {
		return (1 <= id && id <= 8);
	}
}
