package br.com.bocaVermelha.models;

import java.util.HashMap;
import java.util.Map;

import br.com.bocaVermelha.dao.DenunciaDAO;
import br.com.bocaVermelha.entities.Categoria;
import br.com.bocaVermelha.entities.Conexao;
import br.com.bocaVermelha.entities.Denuncia;
import br.com.bocaVermelha.entities.FaixaEtaria;
import br.com.bocaVermelha.entities.Status;
import br.com.bocaVermelha.utils.StringUtils;

/**
 * Model Denúncia
 * 
 * Realiza a camada de regras de negócios que faz as validações e o intermédio
 * entre a camada de de Controller <--> Model <--> DAO. 
 *
 */
public class DenunciaModel {
	
	private DenunciaDAO denunciaDAO;
	
	public DenunciaModel() { 
		denunciaDAO = new DenunciaDAO();
	} 
	
	/**
	 * Verifica se todos os dados da denúncia foram inseridos corretamente e, em caso 
	 * afirmativo, envia esse dado para ser adicionado pelo DAO.
	 * @param  denuncia
	 * @throws Exception
	 */
	public void cadastrar(Denuncia denuncia) throws Exception {
		
		// Verifica se todos os campos do json foram recebidos devidamente 
		if(StringUtils.isBlank(denuncia.getNomeVitima()))
			throw new Exception("o Nome da Vítima é obrigatório.");
		
		if(StringUtils.isBlank(denuncia.getEnderecoVitima()))
			throw new Exception("o Endereço da Vítima é Obrigatório.");
		
		if(StringUtils.isBlank(denuncia.getNomeSuspeito()))
			throw new Exception("o Nome do Suspeito é Obrigatório.");
		
		if(StringUtils.isBlank(denuncia.getEnderecoSuspeito() ))
			throw new Exception("o Endereço do Suspeito é Obrigatório.");
		
		if(StringUtils.isBlank(denuncia.getLocalOcorrencia() ))
			throw new Exception("O Local da Ocorrência é Obrigatório.");
		
		if(StringUtils.isBlank(denuncia.getDescricaoOcorrencia() ))
			throw new Exception("a Descrição da Ocorrência é Obrigatório.");
		
		if(StringUtils.isBlank(denuncia.getUfOcorrencia() ))
			throw new Exception("a UF da Ocorrência é Obrigatória.");
		
		if(denuncia.getIdFaixaEtariaVitima() == null || !FaixaEtaria.isValid(denuncia.getIdFaixaEtariaVitima()))
			throw new Exception("Faixa Etária da Vítima inválida.");
		
		if(denuncia.getIdFaixaEtariaSuspeito() == null || !FaixaEtaria.isValid(denuncia.getIdFaixaEtariaSuspeito().intValue()))
			throw new Exception("Faixa Etária do Suspeito inválida.");
		
		if(denuncia.getIdConexaoVitimaSuspeito() == null || !Conexao.isValid(denuncia.getIdConexaoVitimaSuspeito().intValue()))
			throw new Exception("Relação Vítima-Supeito inválida.");
		
		if(denuncia.getIdCategoria() == null || !Categoria.isValid(denuncia.getIdCategoria().intValue()))
			throw new Exception("Categoria de Denúncia inválida.");
		
		// Configurando o Status da Denuncia e inserindo no banco
		denuncia.setIdStatus(Status.AGUARDANDO);
		denuncia.setId( denunciaDAO.inserir(denuncia) );
		
		// Com o ID em mãos, iremos criar o código de acompanhamento e atualizar o registro
		denuncia.setCodigoAcompanhamento(StringUtils.gerarProtocolo(denuncia.getId()));
		denunciaDAO.atualizarCodigoAcompanhamento(denuncia);
	}
	
	/**
	 * Verifica se o código de acompanhamento foi enviado corretamente, envia a busca
	 * para o DAO e faz a limpeza de dados sensíveis que possma comprometer a vitima.
	 * 
	 * @param denuncia
	 * @throws Exception
	 */
	public void acompanhar(Denuncia denuncia) throws Exception {
		
		// Verificando se o código de acompanhamento foi recebido corretamente
		if(StringUtils.isBlank(denuncia.getCodigoAcompanhamento()))
			throw new Exception("É necessário enviar um código de acompanhamento.");
		
		if(denuncia.getCodigoAcompanhamento().trim().length() != 16)
			throw new Exception("o Código de Acompanhamento é inválido.");
		
		// Realizando a busca do registro no banco de dados
		denunciaDAO.buscarPeloAcompanhamento(denuncia);
		
		// Agora iremos remover da denúncia qualquer tipo de dado sensivel que comprometa
		// tanto a vitima e o suspeito quanto a pessoa que fez a denúncia.
		denuncia.setId(0);
		denuncia.setNomeVitima(null);
		denuncia.setEnderecoVitima(null);
		denuncia.setIdFaixaEtariaVitima(0);
		
		denuncia.setNomeSuspeito(null);
		denuncia.setEnderecoSuspeito(null);
		denuncia.setNomesOutrosSuspeitos(null);
		denuncia.setIdFaixaEtariaSuspeito(0);
		
		denuncia.setLocalOcorrencia(null);
		denuncia.setDescricaoOcorrencia(null);
	}
	
	/**
	 * Solicita e monta um HashMap com resultados de diferentes informações do sistema.
	 * @return Relação de resultados
	 * @throws Exception
	 */
	public Map<String, Object> buscarEstatisticas() throws Exception {
		Map<String, Object> estatisticas = new HashMap<String, Object>();
		
		// Busca os dados de quantidade de denúncias por categoria
		estatisticas.put("categorias", denunciaDAO.buscarEstatisticasCategorias());
		
		// Busca os dados da distribuição de faixa etária das vítimas
		estatisticas.put("faixa_etarias", denunciaDAO.buscarEstatisticasIdadeVitima());
		
		// Busca os dados da distribuição de conexão da vitima-suspeito
		estatisticas.put("conexao", denunciaDAO.buscarEstatisticasConexao());
		
		return estatisticas;
	}
	
}
