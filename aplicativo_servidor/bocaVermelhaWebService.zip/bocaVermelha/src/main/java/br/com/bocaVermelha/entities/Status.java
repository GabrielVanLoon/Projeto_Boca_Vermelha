package br.com.bocaVermelha.entities;

/**
 * Entity Status
 * 
 * Implementa os tipos possiveis de status em que uma Denúncia pode se encontrar.
 */
public class Status {
	
	public static final int AGUARDANDO  = 1;
	public static final int AVALIACAO   = 2;
	public static final int ENCAMINHADA = 3;
	public static final int ARQUIVADA   = 4;
	
	public static boolean isValid(int id) {
		return (1 <= id && id <= 4);
	}
}
