package com.example.projetojava.models

/**
 * Denuncia
 *
 * Implementa os atributos padrões definidos em um objeto do tipo denúncia.
 */
class Denuncia {

    // Dados da vítima
    var nomeVitima: String?       = null
    var enderecoVitima: String?   = null
    var idFaixaEtariaVitima: Int? = null

    // Dados do(s) suspeito(s)
    var nomeSuspeito: String?         = null
    var enderecoSuspeito: String?     = null
    var idFaixaEtariaSuspeito: Int?   = null
    var nomesOutrosSuspeitos: String? = null

    // Tipo de conexão entre vitima-suspeito
    var idConexaoVitimaSuspeito: Int? = null

    // Dados da Ocorrência
    var localOcorrencia: String?     = null
    var descricaoOcorrencia: String? = null
    var ufOcorrencia: String?        = null
    var idCategoria: Int?            = null

    // Metadados e informações da ocorrência
    var id: Int?                      = null
    var codigoAcompanhamento: String? = null
    var idStatus: Int?                = null
    var dataCriacao: String?          = null
    var dataModificacao: String?      = null
    var mensagem: String?             = null

}
