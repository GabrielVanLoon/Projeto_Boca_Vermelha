package com.example.projetojava.fragments

import android.content.Intent
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button

import com.example.projetojava.R
import com.example.projetojava.activity.DicasActivity
import com.example.projetojava.activity.MainActivity

/**
 * Carrega o conteúdo da tela inicial.
 */
class HomeFragment : Fragment() {

    override fun onCreateView( inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle? ): View? {
        val v: View = inflater.inflate(R.layout.fragment_home, container, false)

        // Configurando as ações dos botões
        val btnDenuncia        =  v.findViewById<Button>(R.id.btn_tela_denuncia)
        val btnAcompanhamento  =  v.findViewById<Button>(R.id.btn_tela_acompanhamento)
        val btnEstatisticas    =  v.findViewById<Button>(R.id.btn_tela_estatisticas)
        val btnDicas           =  v.findViewById<Button>(R.id.btn_tela_dicas)
        val btnQuemSomos       =  v.findViewById<Button>(R.id.btn_tela_quemsomos)

        btnDenuncia.setOnClickListener { view ->
            (activity as MainActivity).changeFrameContent(DenunciarFragment())
        }

        btnAcompanhamento.setOnClickListener { view ->
            (activity as MainActivity).changeFrameContent(AcompanhamentoFragment())
        }

        btnEstatisticas.setOnClickListener { view ->
            (activity as MainActivity).changeFrameContent(EstatisticasFragment())
        }

        btnDicas.setOnClickListener { view ->
            val intent = Intent(context, DicasActivity::class.java)
            startActivity(intent)
        }

        btnQuemSomos.setOnClickListener { view ->
            (activity as MainActivity).changeFrameContent(QuemSomosFragment())
        }

        return v
    }

}
