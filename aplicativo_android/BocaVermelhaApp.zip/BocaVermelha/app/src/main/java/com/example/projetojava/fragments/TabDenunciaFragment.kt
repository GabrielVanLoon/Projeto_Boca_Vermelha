package com.example.projetojava.fragments


import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast

import com.example.projetojava.R
import kotlinx.android.synthetic.main.fragment_tab_denuncia2.*


/**
 * Carrega o conteúdo das Abas de Dicas e Orientações. Para indicar qual das abas deve ser recebida o Fragment
 * recebe no bundle uma key "tabName" -> "nome". Caso contrário mostra a tab inicial
 */
class TabDenunciaFragment : Fragment() {


    override fun onCreateView(  inflater: LayoutInflater, container: ViewGroup?,
                                savedInstanceState: Bundle? ): View? {

        // Definindo qual aba será aberta
        var tabName: String = "denuncia"
        arguments?.getString("tabName")?.let {
            tabName = it
        }

        // Inflando a aba selecionada
        val layoutId = selectTab(tabName)
        val v: View  = inflater.inflate(layoutId, container, false)

        // Configurando o conteúdo da aba
        configurarConteudo(layoutId, tabName, v)

        return v
    }

    /**
     * Define qual layout será carregado de acordo com a key recebida
     */
    fun selectTab(key: String = "denuncia") : Int {
        if(key.equals("denuncia"))
            return R.layout.fragment_tab_denuncia
        else
            return R.layout.fragment_tab_denuncia2
    }

    /**
     * Define quais textos serão carregados de acordo com a aba selecionada.
     */
    fun configurarConteudo(layoutId: Int, key: String, view: View?){
        if(layoutId != R.layout.fragment_tab_denuncia){
            view?.let{
                var titulo:        TextView = it.findViewById(R.id.txt_titulo)
                var descricao:     TextView = it.findViewById(R.id.txt_descricao)
                var exemplos:      TextView = it.findViewById(R.id.txt_exemplos)
                var punicoes:      TextView = it.findViewById(R.id.txt_punicoes)
                var responsaveis:  TextView = it.findViewById(R.id.txt_responsaveis)

                when(key) {
                    "domestica" -> {
                        titulo.text        = resources.getString(R.string.tab_domestica_titulo)
                        descricao.text     = resources.getString(R.string.tab_domestica_descricao)
                        exemplos.text      = resources.getString(R.string.tab_domestica_exemplos)
                        punicoes.text      = resources.getString(R.string.tab_domestica_punicoes)
                        responsaveis.text  = resources.getString(R.string.tab_domestica_responsaveis)

                    }

                    "fisica" -> {
                        titulo.text        = resources.getString(R.string.tab_agressao_titulo)
                        descricao.text     = resources.getString(R.string.tab_agressao_descricao)
                        exemplos.text      = resources.getString(R.string.tab_agressao_exemplos)
                        punicoes.text      = resources.getString(R.string.tab_agressao_punicoes)
                        responsaveis.text  = resources.getString(R.string.tab_agressao_responsaveis)
                    }

                    "moral" -> {
                        titulo.text        = resources.getString(R.string.tab_psicologica_titulo)
                        descricao.text     = resources.getString(R.string.tab_psicologica_descricao)
                        exemplos.text      = resources.getString(R.string.tab_psicologica_exemplos)
                        punicoes.text      = resources.getString(R.string.tab_psicologica_punicoes)
                        responsaveis.text  = resources.getString(R.string.tab_psicologica_responsaveis)
                    }

                    "sexual" -> {
                        titulo.text        = resources.getString(R.string.tab_sexual_titulo)
                        descricao.text     = resources.getString(R.string.tab_sexual_descricao)
                        exemplos.text      = resources.getString(R.string.tab_sexual_exemplos)
                        punicoes.text      = resources.getString(R.string.tab_sexual_punicoes)
                        responsaveis.text  = resources.getString(R.string.tab_sexual_responsaveis)
                    }

                    "feminicidio" -> {
                        titulo.text        = resources.getString(R.string.tab_feminicidio_titulo)
                        descricao.text     = resources.getString(R.string.tab_feminicidio_descricao)
                        exemplos.text      = resources.getString(R.string.tab_feminicidio_exemplos)
                        punicoes.text      = resources.getString(R.string.tab_feminicidio_punicoes)
                        responsaveis.text  = resources.getString(R.string.tab_feminicidio_responsaveis)
                    }

                    "carcere" -> {
                        titulo.text        = resources.getString(R.string.tab_carcere_titulo)
                        descricao.text     = resources.getString(R.string.tab_carcere_descricao)
                        exemplos.text      = resources.getString(R.string.tab_carcere_exemplos)
                        punicoes.text      = resources.getString(R.string.tab_carcere_punicoes)
                        responsaveis.text  = resources.getString(R.string.tab_carcere_responsaveis)
                    }

                    "trafico" -> {
                        titulo.text        = resources.getString(R.string.tab_trafico_titulo)
                        descricao.text     = resources.getString(R.string.tab_trafico_descricao)
                        exemplos.text      = resources.getString(R.string.tab_trafico_exemplos)
                        punicoes.text      = resources.getString(R.string.tab_trafico_punicoes)
                        responsaveis.text  = resources.getString(R.string.tab_trafico_responsaveis)
                    }

                }
            }
        }
    }


}
