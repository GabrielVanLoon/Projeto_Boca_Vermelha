package com.example.projetojava.retrofit

import com.example.projetojava.services.DenunciaService
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

/**
 * Configura o Retrofit que será responsável pelas requisições REST. Caso o endereço/ip
 * do servidor que receberá as requisições mudar é necessário atualizar a baseUrl tanto neste
 * arquivo quanto em res/xml/network_security_config.xml
 */
class RetrofitConfig{

    // Objeto que será utilizado pelos services
    private val retrofit =  Retrofit.Builder()
        .baseUrl("http://192.168.0.4:8080/bocaVermelha/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    /**
     * Retorna ao usuário a classe responsável pelo Webservice Denúncia já
     * configurada para fazer os acessos À API Rest.
     */
    fun denunciaService () : DenunciaService {
        return retrofit.create(DenunciaService::class.java)
    }


}