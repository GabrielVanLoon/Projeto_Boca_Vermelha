package com.example.projetojava.activity

import android.os.Bundle
import android.support.design.widget.TabLayout
import android.support.v4.app.FragmentManager
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.Toolbar
import android.view.View
import android.widget.Toast
import com.example.projetojava.R
import com.example.projetojava.fragments.TabDenunciaFragment
import kotlinx.android.synthetic.main.activity_dicas.*
import kotlinx.android.synthetic.main.activity_dicas.view.*


class DicasActivity : AppCompatActivity() {

    var fragmentManager: FragmentManager = supportFragmentManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dicas)

        // Configurando o Toolbar da activity
        val dicasToolbar: Toolbar = findViewById(R.id.dicas_toolbar)
        setSupportActionBar(dicasToolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)

        // Carregando o Fragment inicial da Activity
        fragmentManager.beginTransaction().add(R.id.frameContent, TabDenunciaFragment()).commit()

        // Configurando as ações das abas
        tabs_dicas.addOnTabSelectedListener(object: TabLayout.OnTabSelectedListener {
            override fun onTabReselected(p: TabLayout.Tab?) {  }
            override fun onTabUnselected(p: TabLayout.Tab?) { }
            override fun onTabSelected(p: TabLayout.Tab?) {
                p?.let{
                    when(it.position){
                        0 -> changeFrameContent("denuncia")
                        1 -> changeFrameContent("domestica")
                        2 -> changeFrameContent("fisica")
                        3 -> changeFrameContent("moral")
                        4 -> changeFrameContent("sexual")
                        5 -> changeFrameContent("feminicidio")
                        6 -> changeFrameContent("carcere")
                        7 -> changeFrameContent("trafico")
                    }
                }
            }
        })
    }

    // Função executada ao clicar no icone de voltar do ToolBar
    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    /**
     * Função que altera o fragment sendo exibido atualmente
     */
    fun changeFrameContent(tabName: String){
        var bundle = Bundle()
        bundle.putString("tabName", tabName)

        var fragment = TabDenunciaFragment()
        fragment.arguments = bundle
        fragmentManager.beginTransaction().replace(R.id.frameContent, fragment).commit()
    }

}