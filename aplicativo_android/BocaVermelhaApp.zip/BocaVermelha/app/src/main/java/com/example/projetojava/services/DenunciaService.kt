package com.example.projetojava.services

import com.example.projetojava.models.Denuncia
import com.example.projetojava.retrofit.RetrofitConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST
import org.json.JSONObject


/**
 * Interface utilizada pelo Retrofit. Cada função representa um tipo de requisição
 * diferente no Webservice da API Rest.
 */
interface DenunciaService {

    @POST("denuncia/cadastrar")
    fun cadastrarDenuncia(@Body note: Denuncia) : Call<Map<String, String>>

    @POST("denuncia/acompanhamento")
    fun acompanharDenuncia(@Body note: Denuncia) : Call<Map<String, String>>

    @POST("denuncia/estatisticas")
    fun buscarEstatisticas() : Call<Map<String, Object>>

}

/**
 * Interface de resposta para as requisições do DenunciaService
 */
interface DenunciaResponse {

    /**
     * Executado caso a requisição seja finalizada com HTTP_OK
     */
    fun success(message: JSONObject?)

    /**
     * Executado caso a requisição seja finalizada com HTTP_BAD_REQUEST
     */
    fun error(message: JSONObject?)

    /**
     * Executado caso haja erro ao enviar a requisição ao servidor.
     */
    fun failure(message: String?)

    /**
     * Sempre é executado no final da executando, seja ela com erro ou não.
     */
    fun finally()
}


/**
 * Classe que irá fazer os Call's e Callback's. Para o usuário final irá bastar
 * chamar essa classe e definir as operações pode meio da sua interface
 */
class DenunciaWebClient {

    /**
     * @cadastrarDenuncia envia os dados de uma nova denúncia para o servidor e
     * retorna:
     * - HTTP_OK: Mensagem de Sucesso e Código de Acompanhamento
     * -HTTP_BAD_REQUEST: Mensagem de erro
     */
    fun cadastrarDenuncia(denuncia: Denuncia,
                          denunciaResponse: DenunciaResponse) {

        var call = RetrofitConfig().denunciaService().cadastrarDenuncia(denuncia)
        call.enqueue(object: Callback<Map<String, String>?> {

            // Função executada caso a API responde com OK ou com ERROR
            override fun onResponse(call:     Call<Map<String,String>?>?,
                                    response: Response<Map<String, String>?>?) {
                if(response?.code() == 200) {
                    val jObjError: JSONObject? = JSONObject(response?.body())
                    denunciaResponse.success(jObjError)
                } else{
                    val jObjError: JSONObject? = JSONObject(response?.errorBody()?.string())
                    denunciaResponse.error(jObjError)
                }
                denunciaResponse.finally()
            }

            // Função executada caso haja erro ao conectar com a API
            override fun onFailure(call: Call<Map<String,String>?>?,
                                   t: Throwable?) {
                denunciaResponse.failure(t?.message)
                denunciaResponse.finally()
            }
        })

    }

    /**
     * @cadastrarDenuncia envia um código de acompanhamento para o servidor e retorna
     * - HTTP_OK: Objeto do tipo denúncia com dados não sensíveis preenchidos
     * -HTTP_BAD_REQUEST: Mensagem de erro
     */
    fun acompanharDenuncia(denuncia: Denuncia,
                           denunciaResponse: DenunciaResponse) {

        var call = RetrofitConfig().denunciaService().acompanharDenuncia(denuncia)
        call.enqueue(object: Callback<Map<String, String>?> {

            // Função executada caso a API responde com OK ou com ERROR
            override fun onResponse(call:     Call<Map<String,String>?>?,
                                    response: Response<Map<String, String>?>?) {
                if(response?.code() == 200) {
                    val jObjError: JSONObject? = JSONObject(response?.body())
                    denunciaResponse.success(jObjError)
                } else{
                    val jObjError: JSONObject? = JSONObject(response?.errorBody()?.string())
                    denunciaResponse.error(jObjError)
                }
                denunciaResponse.finally()
            }

            // Função executada caso haja erro ao conectar com a API
            override fun onFailure(call: Call<Map<String,String>?>?,
                                   t: Throwable?) {
                denunciaResponse.failure(t?.message)
                denunciaResponse.finally()
            }
        })

    }

    /**
     * @buscarEstatisticas solicita ao servidor os dados para gerar os gráficos
     * - HTTP_OK: Objeto Json com dados para serem inseridos nos gráficos.
     * -HTTP_BAD_REQUEST: Mensagem de erro
     */
    fun buscarEstatisticas(denunciaResponse: DenunciaResponse) {

        var call = RetrofitConfig().denunciaService().buscarEstatisticas()
        call.enqueue(object: Callback<Map<String, Object>?> {

            // Função executada caso a API responde com OK ou com ERROR
            override fun onResponse(call:     Call<Map<String,Object>?>?,
                                    response: Response<Map<String, Object>?>?) {
                if(response?.code() == 200) {
                    val jObjError: JSONObject? = JSONObject(response?.body())
                    denunciaResponse.success(jObjError)
                } else{
                    val jObjError: JSONObject? = JSONObject(response?.errorBody()?.string())
                    denunciaResponse.error(jObjError)
                }
                denunciaResponse.finally()
            }

            // Função executada caso haja erro ao conectar com a API
            override fun onFailure(call: Call<Map<String,Object>?>?,
                                   t: Throwable?) {
                denunciaResponse.failure(t?.message)
                denunciaResponse.finally()
            }
        })

    }

}











