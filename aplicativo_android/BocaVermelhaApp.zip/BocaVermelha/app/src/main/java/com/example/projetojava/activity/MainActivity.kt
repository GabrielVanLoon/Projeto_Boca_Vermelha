package com.example.projetojava.activity

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.NavigationView
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.view.GravityCompat
import android.support.v4.widget.DrawerLayout
import android.support.v7.app.ActionBarDrawerToggle
import android.support.v7.widget.Toolbar
import android.view.MenuItem
import android.widget.Toast
import com.example.projetojava.R
import com.example.projetojava.fragments.*
import kotlinx.android.synthetic.main.activity_main.*

import com.example.projetojava.models.Categoria
import com.example.projetojava.models.Conexao
import com.example.projetojava.models.Denuncia
import com.example.projetojava.models.FaixaEtaria
import com.example.projetojava.services.DenunciaResponse
import com.example.projetojava.services.DenunciaWebClient
import org.json.JSONObject

import android.support.v4.app.FragmentTransaction


/**
 * Activity inicial da aplicação. Nela existe um NavigationDrawer que irá exibir
 * o menu lateral, uma Toolbar e um FragmentManager em que irá ser carregado os
 * diferentes conteúdos da aplicação.
 */
class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    private val fragmentManager: FragmentManager = supportFragmentManager
    private var isHomePage: Boolean              = true


    /**
     * Função executada na criação da Activity
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Configurando a Toolbar e adicionando o evento de abrir/fechar menu
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        val drawerLayout: DrawerLayout   = findViewById(R.id.drawerLayout)
        val navView:      NavigationView = findViewById(R.id.navView)
        val toggle = ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open_drawer, R.string.close_drawer)

        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        // Configurando o evento ao clicar em algum item no menu
        navView.setNavigationItemSelectedListener(this@MainActivity)

        // Carrega o fragment da home que irá ter o menu de seleção
        fragmentManager.beginTransaction().add(R.id.frameContent, HomeFragment()).commit()
    }

    /**
     * Função que altera o fragment sendo exibido atualmente
     */
    fun changeFrameContent(fragment : Fragment?, setHome: Boolean = false){
        fragment?.let {
            fragmentManager.beginTransaction().replace(R.id.frameContent, it).commit()
            isHomePage = setHome
        }
    }



    /**
     * Função utilizada pelo menu de navegação lateral
     */
    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        var newFragment: Fragment? = null

        when(item.itemId){

            R.id.nav_item_home -> changeFrameContent(HomeFragment(), true)

            R.id.nav_item_denuncia -> changeFrameContent(DenunciarFragment())

            R.id.nav_item_acompanhar -> changeFrameContent(AcompanhamentoFragment())

            R.id.nav_item_estatisticas ->  changeFrameContent(EstatisticasFragment())

            R.id.nav_item_dicas -> {
                val intent = Intent(this, DicasActivity::class.java)
                startActivity(intent)
            }

            R.id.nav_item_quemsomos -> changeFrameContent(QuemSomosFragment())
        }

        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    /**
     * Alterando o funcionamento do botão voltar no android
     * Se o menu estiver aberto, então fecha o menu senão fecha a activity
     */
    override fun onBackPressed() {
        if(drawerLayout.isDrawerOpen(GravityCompat.START))
            drawerLayout.closeDrawer(GravityCompat.START)
        else if(!isHomePage)
            changeFrameContent(HomeFragment(), true)
        else
            super.onBackPressed()
    }

}
