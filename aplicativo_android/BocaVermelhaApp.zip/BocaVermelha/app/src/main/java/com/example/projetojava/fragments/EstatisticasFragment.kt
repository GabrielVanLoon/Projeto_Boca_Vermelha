package com.example.projetojava.fragments

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.app.AlertDialog
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import com.anychart.APIlib

import com.anychart.AnyChart
import com.anychart.AnyChartView
import com.anychart.chart.common.dataentry.DataEntry
import com.anychart.chart.common.dataentry.ValueDataEntry
import com.anychart.enums.Align
import com.anychart.enums.LegendLayout
import com.anychart.graphics.vector.StrokeLineJoin
import java.util.ArrayList

import com.example.projetojava.R
import com.example.projetojava.models.Categoria
import com.example.projetojava.models.Status
import com.example.projetojava.services.DenunciaResponse
import com.example.projetojava.services.DenunciaWebClient
import org.json.JSONObject


class EstatisticasFragment : Fragment() {


    override fun onCreateView( inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle? ): View? {
        // Inflate the layout for this fragment
        val V: View = inflater.inflate(R.layout.fragment_estatisticas, container, false)

        // Recuperando os dados da API para carregar os graficos
        context?.let{
            DenunciaWebClient().buscarEstatisticas(object: DenunciaResponse {
                override fun success(message: JSONObject?) {
                    message?.let{ configurarGraficos(V, it) }
                }

                override fun error(message: JSONObject?) {
                    AlertDialog.Builder(it)
                        .setTitle("Erro de Conexão")
                        .setMessage("Ocorreu um erro ao carregar as estatísticas. Tente novamente mais tarde.")
                        .create().show()
                }

                override fun failure(message: String?) {
                    AlertDialog.Builder(it)
                        .setTitle("Erro de Conexão")
                        .setMessage("Mensagem: " + message)
                        .create().show()
                }

                override fun finally() { }

            })
        }


        return V
    }

    /**
     * Utiliza os dados do JSON recebido do Web Service para carregar os gráficos da tela
     */
    private fun configurarGraficos(v: View, jsonData: JSONObject){

        var qtdDenuncias: Int = 0

        // Os três gráficos abaixo tem como base as denúncias do sistema, então o retorno deles é similar,
        // mas caso fossem gráficos diferentes a contagem total de dados poderia ser exibida em algum canto especifico
        // abaixo ou acima do gráfico

        mostrarGrafico(v, R.id.any_chart_view_categoria, R.id.progress_bar_categoria, jsonData.getJSONObject("categorias"))
        mostrarGrafico(v, R.id.any_chart_view_faixa, R.id.progress_bar_faixa,         jsonData.getJSONObject("faixa_etarias"))
        qtdDenuncias = mostrarGrafico(v, R.id.any_chart_view_conexao, R.id.progress_bar_conexao,     jsonData.getJSONObject("conexao"))


        val txtQuantidade: TextView         = v.findViewById(R.id.txt_quantidade_denuncias)
        val progressQuantidade: ProgressBar = v.findViewById(R.id.progress_quantidade_denuncias)

        txtQuantidade.text = ("$qtdDenuncias DENÚNCIAS")
        txtQuantidade.visibility      = View.VISIBLE
        progressQuantidade.visibility = View.GONE

    }

    /**
     * Encapsula toda a etapa de configuração de um gráfico tipo pizza do Any Chart.
     * Além disso, retorna a contagem total de dados utilizados para gerar o gráfico.
     */
    private fun mostrarGrafico(v: View, idChart: Int, idProgress: Int,  jsonData: JSONObject) : Int {
        var countData = 0

        // Preparando os objetos
        val anyChartView = v.findViewById(idChart) as AnyChartView
        APIlib.getInstance().setActiveAnyChartView(anyChartView)
        anyChartView.setProgressBar(v.findViewById(idProgress))

        var pie = AnyChart.pie()
        var data: MutableList<DataEntry> = ArrayList()

        // Carregando os dados
        val numRows: Int = jsonData.getInt("num_rows")
        for(row in 1..numRows){
            var jsonRow = jsonData.getJSONObject(row.toString())
            data.add(ValueDataEntry(jsonRow.getString("descricao"), jsonRow.getInt("count")))
            countData += jsonRow.getInt("count")
        }

        pie.data(data)
        pie.labels().position("outside")
        pie.connectorStroke("#EF5350",2, "2 2", StrokeLineJoin.ROUND, "")
        pie.legend()
        .position("bottom")
        .itemsLayout(LegendLayout.HORIZONTAL_EXPANDABLE)
        .align(Align.CENTER)

        anyChartView.setChart(pie)

        return countData
    }

}
