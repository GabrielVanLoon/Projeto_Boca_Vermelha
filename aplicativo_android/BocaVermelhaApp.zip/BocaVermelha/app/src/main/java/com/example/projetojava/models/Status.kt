package com.example.projetojava.models

/**
 * Model Status
 *
 * Implementa os tipos possiveis de status em que uma Denúncia pode se encontrar.
 */
class Status {

    val AGUARDANDO  = 1
    val AVALIACAO   = 2
    val ENCAMINHADA = 3
    val ARQUIVADA   = 4

    fun isValid(id: Int): Boolean {
        return 1 <= id && id <= 4
    }

    fun getString(id: Int): String {
        when (id){
            1 -> return "Aguardando análise"
            2 -> return "Em avaliação"
            3 -> return "Encaminhada para os órgãos responsáveis"
            4 -> return "Arquivada"
        }
        return ""
    }

    fun getString(id: String?): String {
        id?.let { return return getString(Integer.parseInt(it)) }
        return ""

    }
}