package com.example.projetojava.fragments


import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context.CLIPBOARD_SERVICE
import android.content.DialogInterface
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.app.AlertDialog
import android.text.SpannableStringBuilder
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.*
import com.example.projetojava.R
import com.example.projetojava.models.Denuncia
import com.example.projetojava.services.DenunciaResponse
import com.example.projetojava.services.DenunciaWebClient
import org.json.JSONObject
import android.widget.TextView
import android.support.v4.content.ContextCompat


/**
 * Carrega a tela do formulário de denuncia
 */
class FormularioFragment : Fragment() {

    // Campos do formulario
    var nomeVitima: EditText?       = null
    var enderecoVitima: EditText?   = null
    var faixaEtariaVitima: Spinner? = null

    var nomeAgressor: EditText?     = null
    var enderecoAgressor: EditText? = null
    var faixaEtariaAgressor : Spinner? = null
    var relacao: Spinner? = null

    var tipoAgressao: Spinner?      = null
    var localAgressao: EditText?    = null
    var ufAgressao: EditText?       = null
    var descricao: EditText?        = null

    var botaoEnvio: Button?         = null
    var progress: ProgressBar?      = null
    var errorString: String         = "Este campo é obrigatório"
    val spannableStringBuilder      = SpannableStringBuilder(errorString)


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle? ): View? {
        val V: View = inflater.inflate(R.layout.fragment_formulario, container, false)

        nomeVitima          = V.findViewById(R.id.idNomeVitima)
        enderecoVitima      = V.findViewById(R.id.idEndVitima)
        faixaEtariaVitima   = V.findViewById(R.id.faixaEtariaVitimaSpinner)

        nomeAgressor        = V.findViewById(R.id.idNomeAgressor)
        enderecoAgressor    = V.findViewById(R.id.idEndAgressor)
        faixaEtariaAgressor = V.findViewById(R.id.faixaEtariaAgressorSpinner)
        relacao             = V.findViewById(R.id.relacaoVitimaAgressor)

        tipoAgressao        = V.findViewById(R.id.tipoViolencia)
        localAgressao       = V.findViewById(R.id.idLocal)
        ufAgressao          = V.findViewById(R.id.idUf)
        descricao           = V.findViewById(R.id.idDescricao)

        botaoEnvio          = V.findViewById(R.id.idBotaoEnvio)
        progress            = V.findViewById(R.id.progress_cadastrar)

        configurarListeners(V)

        return V
    }

    /**
     * Configura os listeners e o botão de envio do formulário
     */
    fun configurarListeners(v: View) {

        onChageValidation(v, nomeVitima)
        onChageValidation(v, enderecoVitima)
        onChageValidation(v, nomeAgressor)
        onChageValidation(v, enderecoAgressor)
        onChageValidation(v, localAgressao)
        onChageValidation(v, ufAgressao)
        onChageValidation(v, descricao)

        onSpinnerTouch(faixaEtariaVitima)
        onSpinnerTouch(faixaEtariaAgressor)
        onSpinnerTouch(relacao)
        onSpinnerTouch(tipoAgressao)

        botaoEnvio!!.setOnClickListener {
            if(formularioEstaValido() ){
                hideKeyboard(activity!!)

                botaoEnvio!!.isEnabled  = false
                botaoEnvio!!.visibility = View.GONE
                progress!!.visibility   = View.VISIBLE


                val den = Denuncia()
                den.nomeVitima              = nomeVitima!!.text.toString()
                den.enderecoVitima          = enderecoVitima!!.text.toString()
                den.idFaixaEtariaVitima     = faixaEtariaVitima!!.selectedItemPosition
                den.nomeSuspeito            = nomeAgressor!!.text.toString()
                den.enderecoSuspeito        = enderecoAgressor!!.text.toString()
                den.idFaixaEtariaSuspeito   = faixaEtariaAgressor!!.selectedItemPosition
                den.idConexaoVitimaSuspeito = relacao!!.selectedItemPosition

                den.idCategoria         = tipoAgressao!!.selectedItemPosition
                den.localOcorrencia     = localAgressao!!.text.toString()
                den.descricaoOcorrencia = descricao!!.text.toString()
                den.ufOcorrencia        = ufAgressao!!.text.toString()


                DenunciaWebClient().cadastrarDenuncia(den, object: DenunciaResponse {

                    override fun success(message: JSONObject?) {
                        AlertDialog.Builder(activity!!)
                            .setTitle("Denúncia enviada")
                            .setMessage("Caso queira acompanhar o status da sua denúncia no futuro anote o código de acompanhamento a seguir:\n\n" + message?.getString("code"))
                            .setPositiveButton("Clique para copiar", object: DialogInterface.OnClickListener {
                                override fun onClick(dialog: DialogInterface?, which: Int) {
                                    val clipboard = activity!!.getSystemService(CLIPBOARD_SERVICE) as ClipboardManager?
                                    val clip      = ClipData.newPlainText("Código copiado para o clip-board", message?.getString("code"))
                                    clipboard!!.setPrimaryClip(clip)

                                    Toast.makeText(activity, "Copiado para o clip-board", Toast.LENGTH_LONG).show()
                                }
                            })
                            .create().show()

                        resetarFormulario()
                    }

                    override fun error(message: JSONObject?) {
                        // Toast.makeText(this@MainActivity, "Ocorreu um erro na requisição 2", Toast.LENGTH_LONG).show()
                        AlertDialog.Builder(activity!!)
                            .setTitle("Erro ao cadastrar")
                            .setMessage("Não foi possível cadastrar sua denúncia. Verifique os dados cadastrados e a conexão da sua internet.")
                            .create().show()
                    }

                    override fun failure(message: String?) {
                        //Toast.makeText(this@MainActivity, "Ocorreu um erro na conexão", Toast.LENGTH_LONG).show()
                        AlertDialog.Builder(activity!!)
                                .setTitle("Erro de Conexão")
                                .setMessage("Mensagem: " + message)
                                .create().show()
                    }

                    override fun finally() {
                        botaoEnvio!!.isEnabled  = true
                        botaoEnvio!!.visibility = View.VISIBLE
                        progress!!.visibility   = View.GONE
                    }
                })

            }
        }
    }

    /**
     * Evento que válida um campo de texto toda vez que o campo perde o foco do usuário.
     */
    private fun onChageValidation(v: View, editText: EditText? ){
        editText!!.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                val texto = editText?.text.toString()
                if(campoVazio(texto))
                    editText!!.error = spannableStringBuilder
            }
        }
    }

    /**
     * Implementa duas configurações nos Spinners:
     * - Retira o keyboard na tela quando o dialog do spinner abre
     * - Controla a cor do spinner, pois o primeiro item deve ter a mesma cor que um hint.
     */
    fun onSpinnerTouch(spin: Spinner?){
        // Retira o keyboard caso ele esteja aparecendo
        spin!!.setOnTouchListener (object: View.OnTouchListener{
            override fun onTouch(v: View?, event: MotionEvent?): Boolean {
                hideKeyboard(activity!!)
                return false
            }
        })

        // Ajusta a cor do primeiro elemento
        spin.onItemSelectedListener = object: AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if(position == 0)
                    (parent!!.getChildAt(0) as TextView).setTextColor(ContextCompat.getColor(view!!.context ,R.color.colorLightGrey))
                else
                    (parent!!.getChildAt(0) as TextView).setTextColor(ContextCompat.getColor(view!!.context ,R.color.colorGrey))
                // (parent!!.getChildAt(0) as TextView).setTextSize(TypedValue.COMPLEX_UNIT_SP, 18F)
            }
        }
        spin.setSelection(0, true)
    }

    /**
     * Retorna true caso o campo esteja vazio
     */
    fun campoVazio(valor : String): Boolean {
        return (TextUtils.isEmpty(valor) || valor.trim().isEmpty())
    }

    /**
     * Retorna true caso todos os campos do formulário tenham sido preenchidos corretamente.
     */
    fun formularioEstaValido(): Boolean {
        val nomeV  = nomeVitima?.text.toString()
        val endV   =  enderecoVitima?.text.toString()

        val nomeA  = nomeAgressor?.text.toString()
        val endA   = enderecoAgressor?.text.toString()

        val local     = localAgressao?.text.toString()
        val uf        = ufAgressao?.text.toString()
        val desc      = descricao?.text.toString()

        if (campoVazio(nomeV)) {
            nomeVitima?.requestFocus()
            nomeVitima?.error = spannableStringBuilder
            return false
        } else if(campoVazio(endV)) {
            enderecoVitima?.requestFocus()
            enderecoVitima?.error = spannableStringBuilder
            return false
        } else if (faixaEtariaVitima!!.selectedItem == "Faixa Etária da Vítima") {
            Toast.makeText(context, "Selecione a Faixa Etária da Vítima", Toast.LENGTH_SHORT).show()
            return false
        } else if(campoVazio(nomeA)) {
            nomeAgressor?.requestFocus()
            nomeAgressor?.error = spannableStringBuilder
            return false
        } else if(campoVazio(endA)) {
            enderecoAgressor?.requestFocus()
            enderecoAgressor?.error = spannableStringBuilder
            return false
        } else if (faixaEtariaAgressor!!.selectedItem == "Faixa Etária do Agressor") {
            Toast.makeText(context, "Selecione a Faixa Etária do Agressor", Toast.LENGTH_SHORT).show()
            return false
        } else if (relacao!!.selectedItem == "Relação da Vítima com o Agressor") {
            Toast.makeText(context, "Selecione a Relação da Vítima com o Agressor", Toast.LENGTH_SHORT).show()
            return false
        } else if (tipoAgressao!!.selectedItem == "Tipo de Violência") {
            Toast.makeText(context, "Selecione o Tipo de Violência", Toast.LENGTH_SHORT).show()
            return false
        } else if (campoVazio(local)) {
            localAgressao?.requestFocus()
            localAgressao?.error = spannableStringBuilder
            return false
        } else if(campoVazio(uf)) {
            ufAgressao?.requestFocus()
            ufAgressao?.error = spannableStringBuilder
            return false
        } else if(campoVazio(desc)) {
            descricao?.requestFocus()
            descricao?.error = spannableStringBuilder
            return false
        }

        return true
    }

    /**
     * Reinicia o formulário limpando os campos de texto e alterando os spinners.
     */
    fun resetarFormulario(){
        nomeVitima!!.setText("")
        enderecoVitima!!.setText("")
        faixaEtariaVitima!!.setSelection(0)
        nomeAgressor!!.setText("")
        enderecoAgressor!!.setText("")
        faixaEtariaAgressor!!.setSelection(0)
        relacao!!.setSelection(0)

        tipoAgressao!!.setSelection(0)
        localAgressao!!.setText("")
        descricao!!.setText("")
        ufAgressao!!.setText("")
    }

    /**
     * Utility para fechar o teclado
     */
    fun hideKeyboard(activity: Activity) {
        val imm = activity.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
        var view = activity.currentFocus
        if (view == null) {
            view = View(activity)
        }
        imm.hideSoftInputFromWindow(view.windowToken, 0)
    }

}