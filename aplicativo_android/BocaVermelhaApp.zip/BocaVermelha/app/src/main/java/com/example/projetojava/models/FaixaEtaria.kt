package com.example.projetojava.models

/**
 * Model FaixaEtaria
 *
 * Implementa as possíveis faixa etarias que o sistema irá lidar.
 */
object FaixaEtaria {

    val ATE_14       = 1
    val ENTRE_15_24  = 2
    val ENTRE_25_34  = 3
    val ENTRE_35_44  = 4
    val ENTRE_45_54  = 5
    val ACIMA_55     = 6

    fun isValid(id: Int): Boolean {
        return 1 <= id && id <= 6
    }
}