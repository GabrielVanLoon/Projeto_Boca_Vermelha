package com.example.projetojava.models

/**
 * Model Conexao
 *
 * Implementa os tipos de conexao que podem haver entre uma vitima
 * e um suspeito de uma Denúncia.
 */
object Conexao {

    val PARCEIRO     = 1
    val EX_PARCEIRO  = 2
    val FAMILIAR     = 3
    val PROFISSIONAL = 4
    val AMIGO        = 5
    val DESCONHECIDO = 6

    fun isValid(id: Int): Boolean {
        return 1 <= id && id <= 6
    }
}