package com.example.projetojava.fragments

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button

import com.example.projetojava.R
import com.example.projetojava.activity.MainActivity
import android.content.Intent
import android.net.Uri


class DenunciarFragment : Fragment() {

    override fun onCreateView( inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle? ): View? {
        val v: View = inflater.inflate(R.layout.fragment_denuncia, container, false)

        val btnDiscar    = v.findViewById<Button>(R.id.btn_discar)
        val btnContinuar = v.findViewById<Button>(R.id.btn_continuar)

        btnDiscar.setOnClickListener { view ->
            val callIntent = Intent(Intent.ACTION_DIAL)
            callIntent.data = Uri.parse("tel:190")
            startActivity(callIntent)
        }

        btnContinuar.setOnClickListener { view ->
            (activity as MainActivity).changeFrameContent(FormularioFragment())
        }

        // Inflate the layout for this fragment
        return v
    }

}
