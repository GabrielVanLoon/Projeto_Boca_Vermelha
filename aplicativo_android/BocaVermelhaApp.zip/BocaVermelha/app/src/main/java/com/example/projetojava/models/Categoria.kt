package com.example.projetojava.models

/**
 * Model Status
 *
 * Implementa os tipos possiveis de categoria em que uma Denúncia pode se enquadrar.
 */
class Categoria {

    val VIOLENCIA_DOMESTICA  = 1
    val AGRESSAO_FISICA      = 2
    val AGRESSAO_PSICO_MORAL = 3
    val VIOLENCIA_SEXUAL     = 4
    val FEMINICIDIO          = 5
    val CARCERE_PRIVADO      = 6
    val TRAFICO_MULHERES     = 7
    val OUTRA                = 8


    fun isValid(id: Int): Boolean {
        return 1 <= id && id <= 8
    }

    fun getString(id: Int): String {
        when (id){
            1 -> return "Violência Doméstica ou Familiar"
            2 -> return "Agressão Física"
            3 -> return "Agressão Psicológica ou Moral"
            4 -> return "Assédio ou Violência Sexual"
            5 -> return "Feminicídio"
            6 -> return "Cárcere Privado"
            7 -> return "Tráfico de Mulheres"
            8 -> return "Outro / Não sei dizer"
        }
        return ""
    }

    fun getString(id: String?): String {
        id?.let { return return getString(Integer.parseInt(it)) }
        return ""

    }
}