package com.example.projetojava.fragments

import android.os.Bundle
import android.support.design.widget.TextInputEditText
import android.support.v4.app.Fragment
import android.support.v7.app.AlertDialog
import android.support.v7.widget.CardView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast

import com.example.projetojava.models.Categoria
import com.example.projetojava.models.Denuncia
import com.example.projetojava.models.Status
import com.example.projetojava.services.DenunciaResponse
import com.example.projetojava.services.DenunciaWebClient
import org.json.JSONObject
import android.app.Activity
import android.view.inputmethod.InputMethodManager
import com.example.projetojava.R

/**
 * Carrega a tela de acompanhamento da denúncia.
 */
class AcompanhamentoFragment : Fragment() {

    var btnBuscar: Button?             = null
    var cardDenuncia: CardView?        = null
    var progressDenuncia: ProgressBar? = null


    override fun onCreateView( inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle? ): View? {
        val v: View = inflater.inflate(R.layout.fragment_acompanhamento, container, false)

        val txtCodigo = v.findViewById<TextInputEditText>(R.id.txt_codigo_denuncia)
        btnBuscar        = v.findViewById(R.id.btn_buscar)
        cardDenuncia     = v.findViewById(R.id.card_denuncia)
        progressDenuncia = v.findViewById(R.id.progress_denuncia)

        // Configurando o botão de buscar denuncia
        btnBuscar?.setOnClickListener { view ->

            // Fecha o teclado
            activity?.let { hideKeyboard(it) }

            // Valida o campo e chama a API
            var strCodigo: String = txtCodigo?.text.toString()
            if(!validarCodigo(strCodigo)){
                Toast.makeText(context, "Preencha o código.", Toast.LENGTH_LONG).show()
            } else {
                buscarCadastro(strCodigo)
            }
        }


        // Inflate the layout for this fragment
        return v
    }

    /**
     * Função para validar o formulário
     */
    fun validarCodigo(codigo: String): Boolean {
        return !(codigo.trim().isEmpty())
    }

    /**
     * Encapsula o processo de chamada do DenunciaWebClient().
     *
     * Caso a busca retorne uma denúncia o código irá exibir um card com as informações para o usuário.
     */
    fun buscarCadastro(codigo: String) {
        val den: Denuncia = Denuncia()
        den.codigoAcompanhamento = codigo

        cardDenuncia?.visibility     = View.GONE
        progressDenuncia?.visibility = View.VISIBLE

        context?.let{
            DenunciaWebClient().acompanharDenuncia(den, object: DenunciaResponse {
                override fun success(message: JSONObject?) {

                    var titulo: TextView?     = cardDenuncia?.findViewById(R.id.txt_titulo_denuncia)
                    var categoria: TextView?  = cardDenuncia?.findViewById(R.id.txt_tipo_denuncia)
                    var data: TextView?       = cardDenuncia?.findViewById(R.id.txt_data_denuncia)
                    var status: TextView?     = cardDenuncia?.findViewById(R.id.txt_status_denuncia)
                    var encaminhamento: TextView? = cardDenuncia?.findViewById(R.id.txt_data_encaminhamento)
                    var mensagem: TextView? = cardDenuncia?.findViewById(R.id.txt_mensagem)

                    titulo?.text    = ("DENÚNCIA #" + message?.getString("codigoAcompanhamento"))
                    data?.text      = message?.getString("dataCriacao")
                    categoria?.text = Categoria().getString( message?.getString("idCategoria") )
                    status?.text    = Status().getString( message?.getString("idStatus") )


                    // Ajustes para mensagem e encaminhamento
                    message?.getString("idStatus")?.let {
                        if (Integer.parseInt(it) >= 3) {
                            encaminhamento?.text = message?.getString("dataModificacao")
                        } else {
                            encaminhamento?.text = "Ainda não foi encaminhada"
                        }
                    }

                    if(message?.getString("mensagem") == null || message?.getString("mensagem").equals("null"))
                        mensagem?.text = "Nenhuma mensagem disponível"
                    else
                        mensagem?.text = message?.getString("mensagem")

                    cardDenuncia?.visibility     = View.VISIBLE

                }

                override fun error(message: JSONObject?) {
                    AlertDialog.Builder(it)
                        .setTitle("Denúncia não encontrada")
                        .setMessage("Por favor, verifique se o código de acompanhamento foi digitado corretamente.")
                        .create().show()
                }

                override fun failure(message: String?) {
                    AlertDialog.Builder(it)
                        .setTitle("Erro de Conexão")
                        .setMessage("Mensagem: " + message)
                        .create().show()
                }

                override fun finally() {
                    progressDenuncia?.visibility = View.GONE
                }
            })
        }
    }

    /**
     * Utility para fechar o teclado
     */
    fun hideKeyboard(activity: Activity) {
        val imm = activity.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
        var view = activity.currentFocus
        if (view == null) {
            view = View(activity)
        }
        imm.hideSoftInputFromWindow(view.windowToken, 0)
    }

}
